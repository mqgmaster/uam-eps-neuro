package faaPractica2;

import java.util.ArrayList;


public class Main {

	/**
	 * @param args
	 */

	public static void main(String []args) {
    	Datos datos = new Datos();
		
		if(datos.cargaDeFichero("./files/iris_aleat.data")==false){
			System.out.println("Error en carga fichero");
			return;
		}
    	
		int nPart = 10;
		int nepocas = 500;
		int cteEntrenamiento = 2;
		
		int C = 2;
		int J = 4;
		
		datos.creaParticionesValidacionCruzada(nPart);
		ArrayList<String[]> datosTrain;
		ArrayList<String[]> datosTest;
		ArrayList<String> resultados;
		double mediaError = 0.0;
		
        /*System.out.println("\n----- CLASIFICADOR PERCEPTRON SIMPLE  -----");
        Perceptron_simple ps = new Perceptron_simple();
		for(int i=0; i<nPart; i++){
		//int i=0;
			System.out.println(i);
			datosTrain = datos.extraeDatosTrain(datos.getParticiones().get(i));
			datosTest = datos.extraeDatosTest(datos.getParticiones().get(i));
			
			ps.entrenamiento(nepocas, datosTrain, cteEntrenamiento);
			resultados = ps.clasifica(datosTest);
			
			double error = ps.error(datosTest, resultados);
        	System.out.println("ERROR "+i+": "+error);
			mediaError += error;
		}
        System.out.println("\nMEDIA: "+mediaError/nPart);
        */
        
        System.out.println("\n----- CLASIFICADOR PERCEPTRON MULTICAPA  -----");
        Perceptron_Multicapa pm = new Perceptron_Multicapa();
        mediaError = 0.0;
		for(int i=0; i<nPart; i++){
		//int i=0;
			System.out.println(i);
			datosTrain = datos.extraeDatosTrain(datos.getParticiones().get(i));
			datosTest = datos.extraeDatosTest(datos.getParticiones().get(i));
			
			pm.entrenamiento(nepocas, datosTrain, cteEntrenamiento, C, J);
			resultados = pm.clasifica(datosTest);
			
			double error = pm.error(datosTest, resultados);
        	System.out.println("ERROR "+i+": "+error);
			mediaError += error;
		}
        System.out.println("\nMEDIA: "+mediaError/nPart);
        
        return ;
    }

}

