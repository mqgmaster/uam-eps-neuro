package faaPractica2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import au.com.bytecode.opencsv.CSVReader;/**fuente: http://sourceforge.net/projects/opencsv/  
 					    http://opencsv.sourceforge.net/ */

public class Datos {
	public enum TiposDeAtributos {Continuo, Nominal};

	private ArrayList<TiposDeAtributos> tipoAtributos; //guarda el tipo de atributo de cada columna del fichero
	private ArrayList<String[]> datos; //Guarda los datos del fichero por filas
	private ArrayList<Particion> particiones; //guarda el array de particiones creado con validaci�n cruzada
	private int ndatos;

	/**Constructor: Inicializa las variables de la clase*/
	public Datos(){
		tipoAtributos = new ArrayList<TiposDeAtributos> ();
		datos = new ArrayList<String[]> ();
		particiones = new ArrayList<Particion>();
		ndatos=0;
	}
	
	/**getters**/
	public ArrayList<String[]> getDatos(){
    	return datos;
    }
    public ArrayList<TiposDeAtributos> getTipoAtributos(){
    	return tipoAtributos;
    }
    public ArrayList<Particion> getParticiones() {
		return particiones;
	}

   
	/** Obtiene los datos de entrenamiento a partir de la particion especificada*/
	/**Hace una copia de la posicion solicitada en un nuevo ArrayList<String[]> y lo devuelve*/
	public ArrayList<String[]> extraeDatosTrain(Particion idx){
		ArrayList<String[]> train= new ArrayList<String[]>();
		for (int i= 0; i<idx.indicesTrain.size(); i++){
			train.add(datos.get(idx.indicesTrain.get(i)));
		}
		//TreeMap <Integer, Double> mapa = new TreeMap<Integer, Double>();
		return train;
	}

	/** Obtiene los datos de prueba a partir de la particion especificada*/
	/**Hace una copia de la posicion solicitada en un nuevo ArrayList<String[]> y lo devuelve*/
	public ArrayList<String[]> extraeDatosTest(Particion idx){
		ArrayList<String[]> test= new ArrayList<String[]>();
		for (int i= 0; i<idx.indicesTest.size(); i++){
			test.add(datos.get(idx.indicesTest.get(i)));
		}
		return test;
	}

	/** Esta clase almacena informacion sobre la particion: datos de entrenamiento y test*/
	public class Particion {
		public ArrayList<Integer> indicesTrain;
		public ArrayList<Integer> indicesTest;
		public Particion(){
			indicesTrain = new ArrayList<Integer>();
			indicesTest  = new ArrayList<Integer>();
		}
	}

	/**Dado un fichero rellena la estructura de datos y el número de datos leidos (ndatos)
	 * devuelve si se cargó correctamente o no.*/
	public boolean cargaDeFichero (String nombreDeFichero){

		try {
			CSVReader reader = new CSVReader(new FileReader(nombreDeFichero)); //cargamos el fichero
			String[] linea;//array[] que guarda los valores de una linea.
			//De la primera linea obtenemos el tipo de atributos si son Continuos o Nominales
			linea = reader.readNext();
			for(String l : linea){
				if(l.equals("Continuo"))
					tipoAtributos.add(TiposDeAtributos.Continuo);
				else
					tipoAtributos.add(TiposDeAtributos.Nominal);
			}
			while ((linea = reader.readNext()) != null) { // el resto de lineas las guardamos en datos. 
				datos.add(linea);
				ndatos++;
			}
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	/** Crea las particiones a partir del conjunto de datos. Cada partición incluirá un conjunto
    de entrenamiento y otro de test. Hay tantas particiones como indique "numPart". El conjunto de entrenamiento
    se crea con las numPart-1 particiones y el de test con la partición restante*/
	public Boolean creaParticionesValidacionCruzada (int numPart){
		int tamDatos = ndatos/numPart;//no se contempla que no sea exacto
		int indiceDatos=0;//indice donde empieza la particion de Test
		for (int i = 0; i< numPart; i++){   //Bucle por cada particion
			Particion particion = new Particion ();
			for (int j =indiceDatos; j<indiceDatos+tamDatos;j++){//bucle para la parte de Test
				particion.indicesTest.add(j);
			}
			for (int k = 0; k<indiceDatos; k++){ //Bucle para los indices Train de antes de la parte de Test
				particion.indicesTrain.add(k);
			}
			for(int l = indiceDatos+tamDatos; l<ndatos; l++){//Bucle para los indices Train de despues de la parte de Test
				particion.indicesTrain.add(l);
			}
			indiceDatos= indiceDatos+tamDatos;//actualizamos el indice de Test para la siguiente particion
			particiones.add(particion);
		}
		return true;
	}

}