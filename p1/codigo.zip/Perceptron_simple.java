package faaPractica2;

import java.util.ArrayList;

public class Perceptron_simple {
	public ArrayList <Double> w;
	public String clase1;
	public String clase2;
	
	public Perceptron_simple(){
	
		this.clase1 = "";
		this.clase2 = "";
	}
	
	public void entrenamiento(int nepocas, ArrayList<String[]> datosTrain, int cteEntrenamiento){

		/****************** 0. asignamos las clases C1 y C2 *******************************/		
		String[] claseaux =datosTrain.get(0);
		clase1 =claseaux[datosTrain.get(0).length-1];
		
		int clase; //guardaremos la clase en n�mero. 
		
		
		/****************** 1. generamos pesos aleatorios para w **************************/
		//sacamos el n�mero de atributos +1 que va a sar el tama�o de w
		int n = datosTrain.get(0).length;
		//inicializar aleatoriamente w con el tam atr +1
		this.w = new ArrayList<Double>() ;
		
		for(int i = 0; i<n; i++){
			w.add(Math.random()-0.5);
		}
		
		/******************* 2. calculamos la prob de ser C1 o C2 *************************/
		
		for( int i = 0; i < nepocas; i++){//para cada �poca
			for(int j = 0; j < datosTrain.size(); j++){//para cada ejemplo de x[]
				/***miramos la clase ***/
				if(clase1.equals(datosTrain.get(j)[datosTrain.get(j).length-1])){
					clase = 1;
				}else{
					clase2= datosTrain.get(j)[datosTrain.get(j).length-1];
					clase =0;
				}
				/*** calculamos el valor de yx ***/
				double yx = this.w.get(0); //valor auxiliar 
				for(int k = 0; k< datosTrain.get(j).length - 1; k++){
		            yx+=this.w.get(k+1) * Double.valueOf(datosTrain.get(j)[k]);
		        }
				if(yx >= 0 && clase == 0){
					/*** actualizamos la recta ***/
					for(int u=0; u< w.size(); u++){
						Double valor =0.0; //para poner la xi[0] a unos ya que w es m�s grande que datosTrain[i]
						if(u==0){
							valor = 1.0;
						}else{
							valor = Double.valueOf(datosTrain.get(j)[u-1]);
						}
						double aux = w.get(u) - cteEntrenamiento *valor;
						w.set(u, aux);
					}
				}else if(yx < 0 && clase == 1){
					/*** actualizamos la recta ***/
					
					for(int u=0; u< w.size(); u++){
						Double valor =0.0; //para poner la xi[0] a unos ya que w es m�s grande que datosTrain[i]
						if(u==0){
							valor = 1.0;
						}else{
							valor = Double.valueOf(datosTrain.get(j)[u-1]);
						}
						double aux = w.get(u) + cteEntrenamiento *valor;
						w.set(u, aux);
					}
				}
			}
		}
		return;
	}
	
	
	public ArrayList<String> clasifica (ArrayList<String[]> datosTest){
		
		ArrayList<String> clases = new ArrayList<String>();

		//System.out.println("Clase1="+clase1+" Clase2="+clase2);
		
		for(int i = 0; i< datosTest.size();i++){
			double yx = this.w.get(0); //valor auxiliar 
	        for(int k = 0; k< datosTest.get(i).length - 1; k++){
	            yx+=this.w.get(k+1) * Double.valueOf(datosTest.get(i)[k]);
	        }
	        //System.out.println("YX: "+yx);
	        if(yx >= 0){
	        	clases.add(clase1);
	        }else if( yx < 0){
	        	clases.add(clase2);
	        }else{
	        	clases.add("UNDEFINED");
	        }
		}
		return clases;
	}
 	
	public double error(ArrayList<String[]> datosTest, ArrayList<String> resultados){
        //Aqui se compara con clases reales y se calcula el error
    	double error=0.0;
    	for(int i=0; i<datosTest.size();i++){
//System.out.println(datosTest.get(i)[datosTest.get(i).length-1]+" - "+resultados.get(i));
    		if(datosTest.get(i)[datosTest.get(i).length-1].compareTo(resultados.get(i))!=0){
    			error++;
    		}
    	}
    	error= error/datosTest.size();
        return error;
    }
 	
 	
}
