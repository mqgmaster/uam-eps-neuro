package faaPractica2;

import java.util.ArrayList;

public class Perceptron_Multicapa {
	public ArrayList <ArrayList <Double>> w;
	public ArrayList<ArrayList <Double>> v;
	public ArrayList<String> clases;
	public int N;
	public int J;
	public int K;
	public int I;
	
	public Perceptron_Multicapa(){
	}
		
	public void entrenamiento(int nEpocas, ArrayList<String[]> datosTrain, int cteEntrenamiento, int C, int neuronas){
		/*** Guardamos las clases existentes ***/
		clases = new ArrayList<String>();
		for(String[] linea : datosTrain){
			if(!clases.contains(linea[linea.length-1])){
				clases.add(linea[linea.length-1]);
//System.out.println(linea[linea.length-1]);
			}
		}
		
		/****************** 			Equivalencias 			***************************/		
		N = datosTrain.size(); //N = numero de ejemplos del conjunto de entrenamiento
		J = neuronas+1; //J = numero de neuronas en la capa oculta + z0 // En el enunciado se pide probar con J = I y J = C
		K = C ; //K = C = numero de clases
		I = datosTrain.get(0).length; //I = numero de atributos + 1 de x0
		
		/****************** 1. generamos pesos aleatorios para v y w **************************/
		this.v = new ArrayList<ArrayList<Double>>(); //Matriz Ix(J-1) en ArrayList (J-1)xI
		for(int j = 0; j < J-1; j++){
			ArrayList<Double> aux_v = new ArrayList<Double>();
			for(int i = 0; i < I; i++){
				aux_v.add(Math.random()-0.5);
			}
			this.v.add(aux_v);
		}
		
		this.w = new ArrayList<ArrayList<Double>>(); //Matriz JxK en ArrayList KxJ
		for(int k = 0; k < K; k++){
			ArrayList<Double> aux_w = new ArrayList<Double>();
			for(int j = 0; j < J; j++){
				aux_w.add(Math.random()-0.5);
			}
			this.w.add(aux_w);
		}
	
		/******** 2. Hasta completar cierto numero de epocas *************/
		for (int epoca = 0; epoca < nEpocas; epoca++){		//EPOCAS
		/******** 3. Para cada ejemplo del conjunto de entrenamiento *************/
			for(int n=0; n<N ; n++){
		/******** A. Se calculan las probabilidades a posteriori de pertenencia a cada clase *************/
				ArrayList<Double> zn = new ArrayList<Double>();
				zn.add(1.0); //Ponemos en la primera posicion un 1 para despues realizar el producto vectorial con w
				for(int j=0; j<J-1; j++){
					/* bnj = producto vectorial del ejemplo xni y vij */
					double bnj = v.get(j).get(0); //xn0 * v0j = 1*v0j = v0j
					for(int i=1; i<I; i++){
						bnj += Double.valueOf(datosTrain.get(n)[i-1]) * v.get(j).get(i); //bnj += xni*vij
					}
					/* znj = sigmoidal de bnj */
					double sig = 1.0/(1.0 + Math.exp(-bnj));
					zn.add(sig);
				}
				
				ArrayList<Double> an = new ArrayList<Double>();
				double expA = 0.0;//Sumatorio de exponenciales de ank
				for(int k=0; k<K; k++){
					/* ank = producto vectorial znj y wjk */
					double ank = 0.0;
					for(int j=0; j<J; j++){
						ank += zn.get(j)*w.get(k).get(j);
					}
					an.add(ank);
					expA += Math.exp(ank);
				}
				
				ArrayList<Double> yn = new ArrayList<Double>(); //Clases estimadas
				for(int k=0;k<K; k++){
					double ynk = Math.exp(an.get(k))/expA;
					yn.add(ynk);
//System.out.println(ynk);
				}
				
			/******** B. Se calcula para cada unidad de salida *************/
				int clase = clases.indexOf(datosTrain.get(n)[I-1]);
				ArrayList<Double> deltaW = new ArrayList<Double>();
				for(int k=0; k<K; k++){
					double tnk;
					if(k==clase){
						tnk = 1;
					}else{
						tnk = 0;
					}
//System.out.println(tnk+" ");
					deltaW.add(yn.get(k)-tnk);
				}
			/******** C. Se calcula para cada unidad oculta *************/
				ArrayList<Double> deltaV = new ArrayList<Double>();
				for(int j=0; j<J; j++){
					double dv = 0.0;
					for(int k=1; k<K; k++){
						double a = deltaW.get(k);
						double b = w.get(k).get(j);
						double c = zn.get(j);
						dv += a*b*c*(1-c);//deltaW.get(k)*w.get(k).get(j)*zn.get(j)*(1-zn.get(j));
					}
					deltaV.add(dv);
				}
			/******** D. Se actualizan los pesos *************/
				/* Actualizamos w */
				for(int k=0; k<K; k++){
					for(int j=0; j<J; j++){
						double actual = w.get(k).get(j)-cteEntrenamiento*deltaW.get(k)*zn.get(j);
						w.get(k).set(j, actual);
					}
				}
				/* Actualizamos v */
				for(int j=0; j<J-1; j++){
					for(int i=0; i<I; i++){
						double xni;
						if(i==0){
							xni = 1;
						}else{
							xni = Double.valueOf(datosTrain.get(n)[i-1]);
						}
						double a = v.get(j).get(i);
						double b = deltaV.get(j);
						double actual = a-cteEntrenamiento*b*xni;//v.get(j).get(i)-cteEntrenamiento*deltaV.get(j)*xni;
						v.get(j).set(i, actual);
					}
				}
			}
		}
		return;
	}
	
	
	public ArrayList<String> clasifica (ArrayList<String[]> datosTest){
		
		ArrayList<String> resultados = new ArrayList<String>();

		for(int n=0; n<datosTest.size() ; n++){
			/******** A. Se calculan las probabilidades a posteriori de pertenencia a cada clase *************/
			ArrayList<Double> zn = new ArrayList<Double>();
			zn.add(1.0); //Ponemos en la primera posicion un 1 para despues realizar el producto vectorial con w
			for(int j=0; j<J-1; j++){
				/* bnj = producto vectorial del ejemplo xni y vij */
				double bnj = v.get(j).get(0); //xn0 * v0j = 1*v0j = v0j
				for(int i=1; i<I; i++){
					bnj += Double.valueOf(datosTest.get(n)[i-1]) * v.get(j).get(i); //bnj += xni*vij
				}
				/* znj = sigmoidal de bnj */
				double sig = 1.0/(1.0 + Math.exp(-bnj));
				zn.add(sig);
			}
			
			ArrayList<Double> an = new ArrayList<Double>();
			double expA = 0.0;//Sumatorio de exponenciales de ank
			for(int k=0; k<K; k++){
				/* ank = producto vectorial znj y wjk */
				double ank = 0.0;
				for(int j=0; j<J; j++){
					ank += zn.get(j)*w.get(k).get(j);
				}
				an.add(ank);
				expA += Math.exp(ank);
			}
			
			ArrayList<Double> yn = new ArrayList<Double>(); //Clases estimadas
			double max = Math.exp(an.get(0))/expA;
			int res = 0; 
			for(int k=0;k<K; k++){
				double ynk = Math.exp(an.get(k))/expA;
				yn.add(ynk);
				if(ynk > max){
					max = ynk;
					res = k;
				}
//System.out.println(ynk);
			}
			resultados.add(clases.get(res));
//System.out.println(clases.get(res)+"="+res+" , %"+max);
		}
		
		return resultados;
	}
 	
	public double error(ArrayList<String[]> datosTest, ArrayList<String> resultados){
        //Aqui se compara con clases reales y se calcula el error
    	double error=0.0;
    	for(int i=0; i<datosTest.size();i++){
System.out.println(datosTest.get(i)[datosTest.get(i).length-1]+" - "+resultados.get(i));
    		if(datosTest.get(i)[datosTest.get(i).length-1].compareTo(resultados.get(i))!=0){
    			error++;
    		}
    	}
    	error= error/datosTest.size();
        return error;
    }
 	
 	
}

